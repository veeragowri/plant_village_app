import streamlit as st
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np

# Load model
model = load_model("plant_disease_model.keras")

# Class labels (update as per your dataset)
classes = ['Apple Black Rot', 'Apple Healthy', 'Tomato Late Blight', 'Tomato Healthy']

def predict(img):
    img = image.load_img(img, target_size=(128, 128))
    img_array = image.img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)
    pred = model.predict(img_array)
    return classes[np.argmax(pred)]

st.title("🌿 Plant Disease Detection")
st.write("Upload a leaf image to identify the disease.")

uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "png", "jpeg"])
if uploaded_file is not None:
    st.image(uploaded_file, caption='Uploaded Image.', use_column_width=True)
    with open("temp.jpg", "wb") as f:
        f.write(uploaded_file.read())
    result = predict("temp.jpg")
    st.success(f"Prediction: {result}")
